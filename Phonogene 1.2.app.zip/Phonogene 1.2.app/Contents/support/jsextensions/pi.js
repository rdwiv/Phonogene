inlets = 2
outlets = 2
var a = 0;
var b = 0;

setinletassist(0, "input: x(float/int), result(out0) = x * pi");
setinletassist(1, "input: x(float/int), result(out1) = x * (1/pi)");
setoutletassist(0, "x * pi");
setoutletassist(1, "x * (1/pi)");

function msg_float(v)
{
    if (inlet == 0)    
    {
        a = v * Math.PI; 
        outlet(0,a);
    }
    else   
     {
        b = v * (1 / Math.PI);
        outlet(1,b);
    }
}